package com.example.contactTracing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
