import 'dart:developer';

import 'package:contactTracing/services/metrics/deviceMetrics.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _image =
      'https://c8.alamy.com/comp/HXN8D3/a-cartoon-illustration-of-a-doctor-looking-scared-HXN8D3.jpg';
  Widget _information({String title, String subtitle, VoidCallback tap}) {
    return Padding(
      padding: const EdgeInsets.only(left: 12, right: 12),
      child: Card(
        elevation: 10,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              SizedBox(
                width: Metrics.deviceWidth(context) / 2,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$title',
                      style:
                          TextStyle(fontWeight: FontWeight.w600, fontSize: 24),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    RichText(
                        text: TextSpan(
                            text: '$subtitle',
                            style: TextStyle(color: Colors.blue[400]),
                            recognizer: TapGestureRecognizer()
                              ..onTap = () => tap)),
                  ],
                ),
              ),
              Image.network(_image, width: Metrics.deviceWidth(context) / 3)
            ],
          ),
        ),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(
                Radius.circular(Metrics.deviceWidth(context) / 30))),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 20.0, bottom: 10),
            child: Text('Information',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          ),
          _information(
              title: 'What you can do to protect yourself',
              subtitle: 'Find Out More')
        ],
      ),
    );
  }
}
